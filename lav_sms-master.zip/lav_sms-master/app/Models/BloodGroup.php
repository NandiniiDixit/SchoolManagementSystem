<?php

namespace App\Models;

use Eloquent;

class BloodGroup extends Eloquent
{
    //
}
