### Security Vulnerabilities
If you discover a security vulnerability within LAV_SMS, please send an e-mail to CJ Inspired via cjay.pub@gmail.com. All security vulnerabilities will be promptly addressed.

Please Note that some sections of this project are in the work-in-progress stage and would be updated soon. These include:

The Noticeboard/Calendar in the Dashboard Area
Librarian/Acountant user pages
Library Resources/Study Materials Upload for Students
